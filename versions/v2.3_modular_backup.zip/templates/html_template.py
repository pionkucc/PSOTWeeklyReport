"""
HTML模板模块
负责组装完整的HTML报告页面
"""

from config import TITLE, SUBTITLE, OUTPUT_FILE


def build_html_template(total, metrics_html, charts_html, trend_chart_html, detail_view_html):
    """组装完整HTML报告"""
    return f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{TITLE}</title>
    <script src="https://cdn.jsdelivr.net/npm/echarts@5/dist/echarts.min.js"></script>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Microsoft YaHei', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 30px 20px; }}
        .container {{ max-width: 1400px; margin: 0 auto; }}
        .header {{ text-align: center; margin-bottom: 30px; color: white; }}
        .header h1 {{ font-size: 36px; font-weight: 700; margin-bottom: 10px; text-shadow: 0 2px 10px rgba(0,0,0,0.2); }}
        .header p {{ font-size: 16px; opacity: 0.9; }}
        .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; }}
        .card {{ background: white; border-radius: 16px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); padding: 20px; transition: all 0.3s ease; }}
        .card-full {{ grid-column: 1 / -1; background: white; border-radius: 16px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); padding: 20px 30px; transition: all 0.3s ease; }}
        .card-wide {{ grid-column: span 2; background: white; border-radius: 16px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); padding: 20px; transition: all 0.3s ease; }}
        .metrics-container {{ width: 100%; }}
        .metrics-title {{ text-align: center; font-size: 16px; color: #2c3e50; font-weight: bold; margin-bottom: 20px; font-family: 'Microsoft YaHei'; }}
        .metrics-row {{ display: flex; gap: 20px; justify-content: stretch; width: 100%; }}
        .metric-card {{ flex: 1; height: 120px; border-radius: 12px; display: flex; flex-direction: column; align-items: stretch; justify-content: center; transition: all 0.3s ease; cursor: default; padding: 15px 18px; position: relative; }}
        .metric-card:hover {{ transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.2); }}
        .metric-header {{ display: flex; justify-content: space-between; align-items: center; }}
        .metric-name {{ font-size: 15px; color: #5a6c7d; font-family: 'Microsoft YaHei'; font-weight: bold; }}
        .metric-icon {{ width: 22px; height: 22px; opacity: 0.7; position: relative; }}
        .icon-task {{ width: 20px; height: 22px; border: 2px solid #fff; border-radius: 4px; position: relative; }}
        .icon-task::before {{ content: ''; position: absolute; top: 5px; left: 4px; width: 10px; height: 2px; background: #fff; border-radius: 1px; }}
        .icon-task::after {{ content: ''; position: absolute; top: 10px; left: 4px; width: 7px; height: 2px; background: #fff; border-radius: 1px; }}
        .icon-bug {{ width: 20px; height: 20px; position: relative; }}
        .icon-bug::before {{ content: ''; position: absolute; top: 3px; left: 5px; width: 10px; height: 14px; border: 2px solid #fff; border-radius: 50% 50% 45% 45%; }}
        .icon-bug::after {{ content: ''; position: absolute; top: 7px; left: 1px; width: 4px; height: 2px; background: #fff; box-shadow: 12px 0 0 #fff, 6px 6px 0 #fff, 6px 10px 0 #fff; }}
        .icon-chart {{ width: 22px; height: 22px; position: relative; display: flex; align-items: flex-end; justify-content: space-between; }}
        .icon-chart::before {{ content: ''; position: absolute; bottom: 0; left: 0; width: 5px; height: 14px; background: #fff; border-radius: 2px 2px 0 0; }}
        .icon-chart::after {{ content: ''; position: absolute; bottom: 0; right: 0; width: 5px; height: 8px; background: #fff; border-radius: 2px 2px 0 0; }}
        .icon-refresh {{ width: 20px; height: 20px; position: relative; }}
        .icon-refresh::before {{ content: ''; position: absolute; top: 2px; left: 2px; width: 16px; height: 16px; border: 2px solid #fff; border-radius: 50%; border-top-color: transparent; border-left-color: transparent; transform: rotate(-45deg); }}
        .icon-refresh::after {{ content: ''; position: absolute; top: 0; right: 3px; width: 6px; height: 6px; border-top: 2px solid #fff; border-right: 2px solid #fff; transform: rotate(45deg); }}
        .icon-clock {{ width: 20px; height: 20px; border: 2px solid #fff; border-radius: 50%; position: relative; }}
        .icon-clock::before {{ content: ''; position: absolute; top: 3px; left: 7px; width: 2px; height: 6px; background: #fff; border-radius: 1px; }}
        .icon-clock::after {{ content: ''; position: absolute; top: 7px; left: 7px; width: 5px; height: 2px; background: #fff; border-radius: 1px; }}
        .metric-value {{ font-size: 32px; font-weight: bold; color: #2c3e50; font-family: 'Microsoft YaHei'; margin-top: 12px; }}
        .metric-subtitle {{ font-size: 11px; color: #aaa; font-family: 'Microsoft YaHei'; position: absolute; bottom: 8px; right: 15px; line-height: 1.4; text-align: right; }}
        .card:hover {{ transform: translateY(-5px); box-shadow: 0 20px 60px rgba(0,0,0,0.15); }}
        .view-switch {{ position: absolute; top: 20px; right: 20px; display: flex; gap: 8px; }}
        .view-btn {{ padding: 8px 16px; border-radius: 20px; border: 2px solid rgba(255,255,255,0.5); background: rgba(255,255,255,0.1); color: white; font-family: 'Microsoft YaHei'; font-size: 13px; cursor: pointer; transition: all 0.3s ease; }}
        .view-btn:hover {{ background: rgba(255,255,255,0.2); }}
        .view-btn.active {{ background: rgba(255,255,255,0.3); border-color: white; font-weight: bold; }}
        .detail-view {{ display: none; }}
        .detail-view.active {{ display: block; }}
        .chart-view {{ display: block; }}
        .chart-view.hidden {{ display: none; }}
        @media (max-width: 768px) {{ .grid {{ grid-template-columns: 1fr; }} .header h1 {{ font-size: 28px; }} }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header" style="position: relative;">
            <div class="view-switch">
                <button class="view-btn active" data-view="chart" onclick="switchView('chart')">图表视图</button>
                <button class="view-btn" data-view="detail" onclick="switchView('detail')">明细视图</button>
            </div>
            <h1>{TITLE}</h1>
            <p>{SUBTITLE} | 共 {total} 条缺陷数据</p>
        </div>

        <div class="chart-view" id="chartView">
            <div class="grid">
                <div class="card-full">{metrics_html}</div>
                <div class="card-wide">{charts_html[0]}</div>
                <div class="card">{charts_html[1]}</div>
                <div class="card">{charts_html[2]}</div>
                <div class="card-wide">{trend_chart_html}</div>
                {''.join([f'<div class="card">{html}</div>' for html in charts_html[3:]])}
            </div>
        </div>

        <div class="detail-view" id="detailView">
            {detail_view_html}
        </div>
    </div>
    <script>
        function switchView(view) {{
            var chartView = document.getElementById('chartView');
            var detailView = document.getElementById('detailView');
            var btns = document.querySelectorAll('.view-btn');
            btns.forEach(function(btn) {{
                btn.classList.remove('active');
                if (btn.dataset.view === view) btn.classList.add('active');
            }});
            if (view === 'chart') {{ chartView.style.display = 'block'; detailView.style.display = 'none'; }}
            else {{ chartView.style.display = 'none'; detailView.style.display = 'block'; }}
        }}
    </script>
</body>
</html>'''


def save_report(html_content):
    """保存HTML报告到文件"""
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        f.write(html_content)
