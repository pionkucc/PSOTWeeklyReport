"""
明细视图模块
包含缺陷明细列表和弹窗详情功能
"""

import json
import pandas as pd


def create_detail_view_html(df, total):
    """创建缺陷明细视图HTML（筛选导航栏 + 数据表格）"""
    # 定义表格展示列及中文名
    display_cols = {
        '缺陷编号': '缺陷编号',
        '缺陷状态': '缺陷状态',
        '缺陷摘要': '缺陷摘要',
        '优先级': '优先级',
        '严重程度': '严重程度',
        '处理人员': '处理人员',
        '发现阶段': '发现阶段',
        '缺陷类型': '缺陷类型',
        '缺陷修复周期(天)': '修复周期(天)'
    }

    # 定义弹窗明细列及中文名
    detail_cols = {
        '缺陷编号': '缺陷编号',
        '缺陷状态': '缺陷状态',
        '缺陷摘要': '缺陷摘要',
        '优先级': '优先级',
        '严重程度': '严重程度',
        '处理人员': '处理人员',
        '发现阶段': '发现阶段',
        '引入阶段': '引入阶段',
        '引入原因': '引入原因',
        '缺陷来源': '缺陷来源',
        '缺陷类型': '缺陷类型',
        df.columns[9]: '登记人',
        df.columns[11]: '登记时间',
        df.columns[12]: '修改时间',
        df.columns[13]: '关闭时间',
        '缺陷修复周期(天)': '修复周期(天)',
        '缺陷关闭周期(天)': '关闭周期(天)'
    }

    # 登记时间列名（用于排序）
    register_time_col = df.columns[11]

    # 获取筛选器选项
    status_options = sorted(df['缺陷状态'].dropna().unique().tolist())
    handler_options = sorted(df['处理人员'].dropna().unique().tolist())
    priority_options = ['低', '中', '高', '优先']

    # 按登记时间倒序排列
    df_sorted = df.sort_values(by=register_time_col, ascending=False)

    # 生成表格行数据
    table_data = df_sorted[list(display_cols.keys())].fillna('')
    rows_json = table_data.to_dict(orient='records')

    # 生成完整明细数据
    detail_data = df_sorted[list(detail_cols.keys())].fillna('')
    detail_rows_json = detail_data.to_dict(orient='records')

    # 转为JS格式
    rows_js = json.dumps(rows_json, ensure_ascii=False, default=str)
    detail_rows_js = json.dumps(detail_rows_json, ensure_ascii=False, default=str)
    col_keys = list(display_cols.keys())
    col_names = list(display_cols.values())
    detail_col_names = list(detail_cols.values())
    col_keys_js = json.dumps(col_keys, ensure_ascii=False)

    return f'''
<div class="filter-bar">
    <div class="filter-group">
        <span class="filter-label">状态</span>
        <select class="filter-select" id="filterStatus" onchange="filterTable()">
            <option value="">全部</option>
            {''.join([f'<option value="{s}">{s}</option>' for s in status_options])}
        </select>
    </div>
    <div class="filter-group">
        <span class="filter-label">处理人员</span>
        <select class="filter-select" id="filterHandler" onchange="filterTable()">
            <option value="">全部</option>
            {''.join([f'<option value="{h}">{h}</option>' for h in handler_options])}
        </select>
    </div>
    <div class="filter-group">
        <span class="filter-label">优先级</span>
        <select class="filter-select" id="filterPriority" onchange="filterTable()">
            <option value="">全部</option>
            {''.join([f'<option value="{p}">{p}</option>' for p in priority_options])}
        </select>
    </div>
    <button class="reset-btn" onclick="resetFilters()">重置</button>
    <span class="filter-stats" id="filterStats">共 {total} 条</span>
</div>

<div class="detail-table-container">
    <table class="detail-table">
        <thead>
            <tr>
                {''.join([f'<th class="col-{i}">{name}</th>' for i, name in enumerate(col_names)])}
            </tr>
        </thead>
        <tbody id="tableBody">
        </tbody>
    </table>
</div>

<div class="modal-overlay" id="modalOverlay" onclick="closeModal(event)">
    <div class="modal-content" onclick="event.stopPropagation()">
        <div class="modal-header">
            <h3 class="modal-title">缺陷明细</h3>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <div class="modal-body" id="modalBody">
        </div>
    </div>
</div>

<style>
    .filter-bar {{ background: #fff; border-radius: 12px; padding: 16px 20px; margin-bottom: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); display: flex; gap: 16px; align-items: center; flex-wrap: wrap; }}
    .filter-group {{ display: flex; align-items: center; gap: 8px; }}
    .filter-label {{ font-family: 'Microsoft YaHei'; font-size: 13px; color: #666; }}
    .filter-select {{ padding: 6px 12px; border: 1px solid #e0e0e0; border-radius: 6px; font-family: 'Microsoft YaHei'; font-size: 13px; background: #fafafa; cursor: pointer; min-width: 100px; transition: border-color 0.2s; }}
    .filter-select:focus {{ border-color: #AA96DA; outline: none; }}
    .reset-btn {{ padding: 6px 16px; border-radius: 6px; border: 1px solid #AA96DA; background: #fff; color: #AA96DA; font-family: 'Microsoft YaHei'; font-size: 13px; cursor: pointer; transition: all 0.2s; }}
    .reset-btn:hover {{ background: #AA96DA; color: #fff; transform: translateY(-2px); }}
    .filter-stats {{ font-family: 'Microsoft YaHei'; font-size: 13px; color: #AA96DA; margin-left: auto; }}
    .detail-table-container {{ background: #fff; border-radius: 12px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); overflow-x: auto; }}
    .detail-table {{ width: 100%; border-collapse: collapse; font-family: 'Microsoft YaHei'; font-size: 13px; }}
    .detail-table th {{ background: #f5f5f5; color: #666; padding: 12px 10px; text-align: left; font-weight: normal; white-space: nowrap; border-bottom: 1px solid #eee; }}
    .detail-table th:first-child {{ border-radius: 8px 0 0 0; }}
    .detail-table th:last-child {{ border-radius: 0 8px 0 0; }}
    .detail-table tbody tr {{ transition: all 0.15s; }}
    .detail-table tbody tr:hover {{ background: #fafafa; transform: scale(1.01); }}
    .detail-table td {{ padding: 10px; border-bottom: 1px solid #f0f0f0; color: #444; }}
    .detail-table tbody tr:last-child td {{ border-bottom: none; }}
    .detail-table .col-0 {{ min-width: 120px; color: #AA96DA; }}
    .detail-table td.summary-cell {{ max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }}
    .detail-table td.summary-cell:hover {{ white-space: normal; word-break: break-all; background: #fff; box-shadow: 0 2px 8px rgba(170,150,218,0.2); z-index: 10; position: relative; border-radius: 4px; padding: 10px; }}
    .status-tag {{ display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 12px; }}
    .status-New {{ background: #FFF9C4; color: #F9A825; }}
    .status-Closed {{ background: #E8F5E9; color: #66BB6A; }}
    .status-Fixed {{ background: #E0F7FA; color: #4DD0E1; }}
    .status-Pending {{ background: #F3E5F5; color: #AB47BC; }}
    .status-ReOpen {{ background: #FFEBEE; color: #EF5350; }}
    .priority-high {{ color: #EF5350; }}
    .priority-medium {{ color: #FFA726; }}
    .priority-low {{ color: #AA96DA; }}
    .modal-overlay {{ display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(170,150,218,0.15); backdrop-filter: blur(8px); z-index: 1000; justify-content: center; align-items: center; }}
    .modal-overlay.active {{ display: flex; }}
    .modal-content {{ background: rgba(255,255,255,0.95); border-radius: 16px; width: 90%; max-width: 600px; max-height: 80vh; overflow: hidden; box-shadow: 0 12px 40px rgba(170,150,218,0.2); animation: modalPop 0.4s cubic-bezier(0.34, 1.56, 0.64, 1); }}
    @keyframes modalPop {{ from {{ transform: scale(0.8) translateY(-30px); opacity: 0; }} to {{ transform: scale(1) translateY(0); opacity: 1; }} }}
    .modal-header {{ background: #f8f9fa; color: #AA96DA; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #eee; }}
    .modal-title {{ margin: 0; font-family: 'Microsoft YaHei'; font-size: 16px; font-weight: normal; }}
    .modal-close {{ background: #fff; border: 1px solid #eee; color: #AA96DA; font-size: 20px; cursor: pointer; line-height: 1; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: all 0.3s; }}
    .modal-close:hover {{ transform: rotate(90deg); background: #AA96DA; border-color: #AA96DA; color: #fff; }}
    .modal-body {{ padding: 20px; max-height: 60vh; overflow-y: auto; }}
    .detail-item {{ display: flex; padding: 12px 16px; border-radius: 8px; margin-bottom: 8px; background: #fff; transition: all 0.2s; }}
    .detail-item:hover {{ background: #fafafa; transform: translateX(6px); }}
    .detail-item:last-child {{ margin-bottom: 0; }}
    .detail-label {{ width: 90px; flex-shrink: 0; font-family: 'Microsoft YaHei'; font-size: 13px; color: #AA96DA; font-weight: bold; }}
    .detail-value {{ flex: 1; font-family: 'Microsoft YaHei'; font-size: 13px; color: #333; word-break: break-all; }}
    .modal-body::-webkit-scrollbar {{ width: 4px; }}
    .modal-body::-webkit-scrollbar-thumb {{ background: #AA96DA; border-radius: 2px; }}
</style>

<script>
(function() {{
    var allData = {rows_js};
    var allDetailData = {detail_rows_js};
    var colKeys = {col_keys_js};
    var detailColNames = {json.dumps(detail_col_names, ensure_ascii=False)};

    function renderTable(data, detailIndices) {{
        var tbody = document.getElementById('tableBody');
        var html = '';
        data.forEach(function(row, dataIdx) {{
            var detailIdx = detailIndices[dataIdx];
            html += '<tr ondblclick="showDetail(' + detailIdx + ')">';
            colKeys.forEach(function(key, idx) {{
                var val = row[key] !== undefined && row[key] !== null ? row[key] : '';
                if (key === '缺陷状态') {{
                    html += '<td><span class="status-tag status-' + val + '">' + val + '</span></td>';
                }} else if (key === '优先级') {{
                    var cls = val === '优先' || val === '高' ? 'priority-high' : (val === '中' ? 'priority-medium' : 'priority-low');
                    html += '<td><span class="' + cls + '">' + val + '</span></td>';
                }} else if (key === '缺陷摘要') {{
                    html += '<td class="summary-cell" title="' + val.replace(/"/g, '&quot;') + '">' + val + '</td>';
                }} else {{
                    html += '<td>' + val + '</td>';
                }}
            }});
            html += '</tr>';
        }});
        tbody.innerHTML = html;
        document.getElementById('filterStats').textContent = '共 ' + data.length + ' 条';
    }}

    window.filterTable = function() {{
        var status = document.getElementById('filterStatus').value;
        var handler = document.getElementById('filterHandler').value;
        var priority = document.getElementById('filterPriority').value;
        var filtered = [], detailIndices = [];
        allData.forEach(function(row, idx) {{
            if (status && row['缺陷状态'] !== status) return;
            if (handler && row['处理人员'] !== handler) return;
            if (priority && row['优先级'] !== priority) return;
            filtered.push(row);
            detailIndices.push(idx);
        }});
        renderTable(filtered, detailIndices);
    }};

    window.resetFilters = function() {{
        document.getElementById('filterStatus').value = '';
        document.getElementById('filterHandler').value = '';
        document.getElementById('filterPriority').value = '';
        var indices = allData.map(function(_, i) {{ return i; }});
        renderTable(allData, indices);
    }};

    window.showDetail = function(idx) {{
        var data = allDetailData[idx];
        var keys = Object.keys(data);
        var html = '';
        keys.forEach(function(key, i) {{
            var val = data[key] !== undefined && data[key] !== null && data[key] !== '' ? data[key] : '--';
            if (key === '缺陷状态') {{
                val = '<span class="status-tag status-' + val + '">' + val + '</span>';
            }} else if (key === '优先级') {{
                var cls = val === '优先' || val === '高' ? 'priority-high' : (val === '中' ? 'priority-medium' : 'priority-low');
                val = '<span class="' + cls + '">' + val + '</span>';
            }}
            html += '<div class="detail-item"><div class="detail-label">' + detailColNames[i] + '</div><div class="detail-value">' + val + '</div></div>';
        }});
        document.getElementById('modalBody').innerHTML = html;
        document.getElementById('modalOverlay').classList.add('active');
    }};

    window.closeModal = function(e) {{
        if (e && e.target !== document.getElementById('modalOverlay')) return;
        document.getElementById('modalOverlay').classList.remove('active');
    }};

    var indices = allData.map(function(_, i) {{ return i; }});
    renderTable(allData, indices);
}})();
</script>
'''
