"""视图模块"""
from .chart_views import *
from .detail_view import create_detail_view_html
