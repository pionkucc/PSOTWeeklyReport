"""
数据处理模块
负责读取Excel数据并进行预处理
"""

import pandas as pd
import numpy as np
from config import INPUT_FILE


def load_data():
    """读取Excel数据，返回 DataFrame 和统计数据"""
    df = pd.read_excel(INPUT_FILE)
    total = len(df)

    # 从sheet2读取任务项统计
    df_sheet2 = pd.read_excel(INPUT_FILE, sheet_name=1)
    task_count = len(df_sheet2) - 1
    subtask_count = df_sheet2.iloc[-1, 4] if len(df_sheet2) > 0 else 0

    return df, total, task_count, subtask_count


def preprocess_data(df):
    """预处理数据，修复周期列类型转换"""
    df['缺陷修复周期(天)'] = pd.to_numeric(
        df['缺陷修复周期(天)'].replace('/', np.nan), errors='coerce'
    )
    return df
